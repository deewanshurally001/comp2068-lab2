'use strict';
var express = require('express');
var router = express.Router();

   
    /* GET home page. */
    router.get('/', function (req, res) {
   
        function calculate(method, x, y) {
            var result = 0;
            switch (method) {
                case "add":
                    result = parseInt(x) + parseInt(y);
                    res.write(x + " + " + y + "  = " + result);
                    res.end();
                case "subtract":
                    result = parseInt(x) - parseInt(y);
                    res.write(x + " - " + y + "  = " + result);
                    res.end();
                case "multiply":
                    result = parseInt(x) * parseInt(y);
                    res.write(x + " * " + y + "  = " + result);
                    res.end();
                case "divide":
                    result = parseFloat(x) / parseFloat(y);
                    res.write(x + " /" +  y  + "  = " + result);
                    res.end();
                default:
                    res.write("Wrong method name");
            }

        }
        console.log(calculate);
        console.log(req.query);
        console.log(req.query.method);
        res.render('index', { title: 'Express' });
});

module.exports = router;
